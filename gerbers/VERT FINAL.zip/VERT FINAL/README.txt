Outline is in .GTL layer

There is no .GTP or .GBO layer

Drill holes are overlapped, this is on purpose.  A picture of the final result is included.

All files made in Eagle Light v.6.5.0 for linux
